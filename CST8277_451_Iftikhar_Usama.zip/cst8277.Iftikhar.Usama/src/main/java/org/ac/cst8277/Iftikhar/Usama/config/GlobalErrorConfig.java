package org.ac.cst8277.Iftikhar.Usama.config;

import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import java.nio.charset.StandardCharsets;

@Configuration
@Order(-2)
public class GlobalErrorConfig implements ErrorWebExceptionHandler {

    @Override
    public Mono<Void> handle(ServerWebExchange exchange, Throwable ex) {
        if (ex instanceof ResponseStatusException && 
           ((ResponseStatusException) ex).getStatusCode() == HttpStatus.NOT_FOUND) {
            
            exchange.getResponse().setStatusCode(HttpStatus.NOT_FOUND);
            exchange.getResponse().getHeaders().setContentType(MediaType.TEXT_HTML);

            String errorPage = "<html><body style='background:#f4e4bc;text-align:center;padding:50px;font-family:serif;'>" +
                               "<h1>404 - Lost in the Wilderness</h1>" +
                               "<p>Alas! You have wandered beyond the Guild's maps.</p>" +
                               "<a href='/login'>Return to the Guild Gates</a>" +
                               "</body></html>";
            
            byte[] bytes = errorPage.getBytes(StandardCharsets.UTF_8);
            return exchange.getResponse().writeWith(Mono.just(exchange.getResponse()
                    .bufferFactory().wrap(bytes)));
        }

        return Mono.error(ex);
    }
}