package org.ac.cst8277.Iftikhar.Usama.controller;

import org.ac.cst8277.Iftikhar.Usama.model.User;
import org.ac.cst8277.Iftikhar.Usama.service.AuthService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import reactor.core.publisher.Mono;

import java.util.UUID;

@Controller
public class WebController {
	
    private final AuthService authService;

    public WebController(AuthService authService) {
        this.authService = authService;
    }

    // Displays the Village Square (Index)
    @GetMapping("/")
    public String landingPage() {
        return "index";
    }

    // Displays the GitHub-only Login page
    @GetMapping("/login")
    public String gates() { 
        return "login"; 
    }
    
    // Displays the Manual Credential Entry page
    @GetMapping("/manual-login")
    public Mono<String> manualLogin() {
        return Mono.just("manual-login");
    }

    // Displays the New Member Registration page
    @GetMapping("/register")
    public String ledger() { 
        return "register"; 
    }

    // Displays the Great Hall Board after validating the UUID Token
    @GetMapping("/board")
    public Mono<String> board(@RequestParam String token, Model model) {
        return authService.validateTokenReactive(UUID.fromString(token))
            .doOnNext(user -> {
                model.addAttribute("username", user.getUsername());
                model.addAttribute("token", token);
                model.addAttribute("isMaster", user.getRoles().contains("PRODUCER"));
            })
            .thenReturn("board")
            .defaultIfEmpty("redirect:/login");
    }
}