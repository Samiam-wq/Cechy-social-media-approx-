package org.ac.cst8277.Iftikhar.Usama.repository;

import org.ac.cst8277.Iftikhar.Usama.model.Post;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import java.util.List;

public interface PostRepository extends ReactiveCrudRepository<Post, Long> {

	Flux<Post> findAllByProducerIdIn(List<Long> producerIds);

    @Query("SELECT * FROM posts ORDER BY created_at DESC LIMIT 5")
    Flux<Post> findTop5Recent();

    @Query("SELECT p.* FROM posts p JOIN users u ON p.producer_id = u.id " +
           "WHERE u.username LIKE CONCAT('%', :query, '%') " +
           "OR p.content LIKE CONCAT('%', :query, '%') " +
           "ORDER BY p.created_at DESC LIMIT 5")
    
    Flux<Post> searchGlobalArchives(String query);
}