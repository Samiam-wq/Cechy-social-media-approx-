package org.ac.cst8277.Iftikhar.Usama.model;

public enum Role {
	
    PRODUCER,
    SUBSCRIBER
}