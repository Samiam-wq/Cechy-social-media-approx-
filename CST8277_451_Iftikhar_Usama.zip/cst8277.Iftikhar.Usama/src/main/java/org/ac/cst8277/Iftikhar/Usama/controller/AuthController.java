package org.ac.cst8277.Iftikhar.Usama.controller;

import org.ac.cst8277.Iftikhar.Usama.dto.LoginRequest;
import org.ac.cst8277.Iftikhar.Usama.dto.UserDTO;
import org.ac.cst8277.Iftikhar.Usama.model.User;
import org.ac.cst8277.Iftikhar.Usama.repository.UserRepository;
import org.ac.cst8277.Iftikhar.Usama.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Arrays;
import java.util.UUID;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;

    public AuthController(AuthService authService, UserRepository userRepository) {
        this.authService = authService;
        this.userRepository = userRepository;
    }

    @PostMapping("/login")
    public Mono<ResponseEntity<UUID>> login(@RequestBody LoginRequest request) {
        return authService.authenticate(request.getUsername(), request.getPassword())
            .map(ResponseEntity::ok)
            .defaultIfEmpty(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }

    @PostMapping("/register")
    public Mono<ResponseEntity<String>> register(ServerWebExchange exchange) {
        return exchange.getFormData().flatMap(formData -> {
            String username = formData.getFirst("username");
            String password = formData.getFirst("password");
            String role = formData.getFirst("role");
            if (username == null || username.trim().isEmpty() || 
                password == null || password.trim().isEmpty()) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Fields cannot be empty in the Guild Ledger."));
            }

            return userRepository.findByUsername(username)
                .flatMap(existing -> Mono.just(ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("That name is already inscribed in the Ledger.")))
                .switchIfEmpty(Mono.defer(() -> {
                    User newUser = new User();
                    newUser.setUsername(username);
                    newUser.setPassword(password); // NoOpPasswordEncoder is used in your config
                    newUser.setRoles(role);
                    return userRepository.save(newUser)
                            .map(saved -> ResponseEntity.ok("Success"));
                }));
        });
    }

    @GetMapping("/verify")
    public ResponseEntity<UserDTO> verify(@RequestParam UUID token) {
        User user = authService.validateToken(token);
        if (user != null) {
            UserDTO dto = new UserDTO(
                user.getId(), 
                user.getUsername(), 
                Arrays.asList(user.getRoles().split(","))
            );
            return ResponseEntity.ok(dto);
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
}