package org.ac.cst8277.Iftikhar.Usama.service;

import org.ac.cst8277.Iftikhar.Usama.model.Post;
import org.ac.cst8277.Iftikhar.Usama.model.Subscription;
import org.ac.cst8277.Iftikhar.Usama.repository.PostRepository;
import org.ac.cst8277.Iftikhar.Usama.repository.SubRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Service
public class TwitterService {

    private final PostRepository postRepository;
    private final SubRepository subRepository;

    public TwitterService(PostRepository postRepository, SubRepository subRepository) {
        this.postRepository = postRepository;
        this.subRepository = subRepository;
    }

    public Mono<Post> createNotice(Long masterId, String content) {
        Post post = new Post();
        post.setProducerId(masterId);
        post.setContent(content);
        post.setCreatedAt(LocalDateTime.now());
        return postRepository.save(post);
    }

    public Flux<Post> getPledgedFeed(Long subscriberId) {
        return subRepository.findBySubscriberId(subscriberId)
            .map(Subscription::getProducerId)
            .collectList()
            .flatMapMany(postRepository::findAllByProducerIdIn);
    }

    public Mono<Subscription> pledgeAllegiance(Long subscriberId, Long producerId) {
        Subscription sub = new Subscription();
        sub.setSubscriberId(subscriberId);
        sub.setProducerId(producerId);
        return subRepository.save(sub);
    }
    public Flux<Post> searchArchives(String query) {
        if (query == null || query.trim().isEmpty()) {
            return postRepository.findTop5Recent();
        }
        return postRepository.searchGlobalArchives(query);
    }
}