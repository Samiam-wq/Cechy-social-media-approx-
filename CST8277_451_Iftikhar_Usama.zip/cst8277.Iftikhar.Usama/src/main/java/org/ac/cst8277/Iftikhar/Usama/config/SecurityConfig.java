package org.ac.cst8277.Iftikhar.Usama.config;

import org.ac.cst8277.Iftikhar.Usama.repository.UserRepository;
import org.ac.cst8277.Iftikhar.Usama.security.OAuthSuccessHandler;
import org.ac.cst8277.Iftikhar.Usama.security.TokenAuthFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Bean
    public ReactiveUserDetailsService userDetailsService(UserRepository userRepository) {
        return username -> userRepository.findByUsername(username)
                .map(u -> User.withUsername(u.getUsername())
                        .password(u.getPassword())
                        .authorities(u.getRoles().split(","))
                        .build());
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }
    
    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http, TokenAuthFilter tokenFilter, OAuthSuccessHandler oauthHandler) {
        return http
            .csrf(csrf -> csrf.disable()) 
            .httpBasic(httpBasic -> httpBasic.disable()) 
            .formLogin(form -> form.disable()) 
            .authorizeExchange(exchanges -> exchanges
            	 .pathMatchers("/", "/auth/**", "/login", "/register",  "/manual-login", "/oauth2/**", "/error/**").permitAll()
            	 .anyExchange().authenticated()
            )
            .addFilterAt(tokenFilter, SecurityWebFiltersOrder.AUTHENTICATION)
            .oauth2Login(oauth -> oauth.authenticationSuccessHandler(oauthHandler))
            .build();
    }
}