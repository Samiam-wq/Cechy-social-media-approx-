package org.ac.cst8277.Iftikhar.Usama.security;

import org.ac.cst8277.Iftikhar.Usama.model.User;
import org.ac.cst8277.Iftikhar.Usama.repository.UserRepository;
import org.ac.cst8277.Iftikhar.Usama.service.AuthService;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.server.DefaultServerRedirectStrategy;
import org.springframework.security.web.server.ServerRedirectStrategy;
import org.springframework.security.web.server.WebFilterExchange;
import org.springframework.security.web.server.authentication.ServerAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.UUID;

@Component
public class OAuthSuccessHandler implements ServerAuthenticationSuccessHandler {

    private final ServerRedirectStrategy redirectStrategy = new DefaultServerRedirectStrategy();
    private final UserRepository userRepository;
    private final AuthService authService;

    public OAuthSuccessHandler(UserRepository userRepository, AuthService authService) {
        this.userRepository = userRepository;
        this.authService = authService;
    }

    @Override
    public Mono<Void> onAuthenticationSuccess(WebFilterExchange webFilterExchange, Authentication authentication) {
        OAuth2User oauthUser = (OAuth2User) authentication.getPrincipal();
        String githubId = oauthUser.getAttribute("id").toString();
        String login = oauthUser.getAttribute("login");

        return userRepository.findByGithubId(githubId)
            .switchIfEmpty(userRepository.save(new User(null, login, null, githubId, "PRODUCER,SUBSCRIBER")))
            .flatMap(user -> {
                UUID token = authService.generateTokenForOAuthUser(user);

                return redirectStrategy.sendRedirect(webFilterExchange.getExchange(), 
                        URI.create("/board?token=" + token));
            });
    }
}