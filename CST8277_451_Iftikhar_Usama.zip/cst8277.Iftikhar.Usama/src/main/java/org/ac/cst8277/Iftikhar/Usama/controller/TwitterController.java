package org.ac.cst8277.Iftikhar.Usama.controller;

import org.ac.cst8277.Iftikhar.Usama.dto.UserDTO;
import org.ac.cst8277.Iftikhar.Usama.model.Post;
import org.ac.cst8277.Iftikhar.Usama.model.Subscription;
import org.ac.cst8277.Iftikhar.Usama.service.TwitterService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class TwitterController {

    private final TwitterService twitterService;

    public TwitterController(TwitterService twitterService) {
        this.twitterService = twitterService;
    }

    @PostMapping("/tweets")
    public Mono<Post> postNotice(@RequestBody String content, ServerWebExchange exchange) {
        UserDTO user = exchange.getAttribute("authenticatedUser");
        if (user == null) return Mono.error(new RuntimeException("Unauthorized"));
        return twitterService.createNotice(user.getId(), content);
    }

    @GetMapping("/tweets/search")
    public Flux<Post> search(@RequestParam(required = false) String query) {
        // This now handles content, usernames, and empty searches consistently
        return twitterService.searchArchives(query);
    }

    @GetMapping("/tweets/feed")
    public Flux<Post> getFeed(ServerWebExchange exchange) {
        UserDTO user = exchange.getAttribute("authenticatedUser");
        if (user == null) {
            return Flux.empty(); // Or return a 401 error signal
        }
        return twitterService.getPledgedFeed(user.getId());
    }

    @PostMapping("/subscribe/{producerId}")
    public Mono<Subscription> subscribe(@PathVariable Long producerId, ServerWebExchange exchange) {
        UserDTO user = exchange.getAttribute("authenticatedUser");
        if (user == null) return Mono.error(new RuntimeException("Unauthorized"));
        return twitterService.pledgeAllegiance(user.getId(), producerId);
    }
}