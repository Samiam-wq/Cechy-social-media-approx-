package org.ac.cst8277.Iftikhar.Usama.security;

import org.ac.cst8277.Iftikhar.Usama.dto.UserDTO;
import org.ac.cst8277.Iftikhar.Usama.model.User;
import org.ac.cst8277.Iftikhar.Usama.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.Arrays;
import java.util.UUID;

@Component
public class TokenAuthFilter implements WebFilter {

    private final AuthService authService;

    public TokenAuthFilter(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String path = exchange.getRequest().getURI().getPath();

        // Path Bypassing: Allow HTML views and essential Auth endpoints to load without a token
        if (path.equals("/manual-login")||path.equals("/") || path.equals("/board") || path.startsWith("/auth") || 
            path.startsWith("/login") || path.startsWith("/register") || 
            path.startsWith("/oauth2") || path.startsWith("/h2-console") || 
            path.equals("/favicon.ico") || path.startsWith("/manual-login")) {
            return chain.filter(exchange);
        }
        
        // Token Extraction: Look for the UUID in the "Authorization" header
        String tokenStr = exchange.getRequest().getHeaders().getFirst("Authorization");
        if (tokenStr == null || tokenStr.isEmpty()) {
            return unauthorized(exchange);
        }

        // Reactive Validation: Use boundedElastic to prevent blocking the Netty event loop
        return Mono.fromCallable(() -> {
            try {
                return authService.validateToken(UUID.fromString(tokenStr));
            } catch (IllegalArgumentException e) {
                return null;
            }
        })
        .subscribeOn(Schedulers.boundedElastic())
        .flatMap(user -> {            
            if (user == null) return unauthorized(exchange);
            UserDTO userDto = new UserDTO(
                user.getId(), 
                user.getUsername(), 
                Arrays.asList(user.getRoles().split(","))
            );
            if (path.equals("/api/tweets") && "POST".equalsIgnoreCase(exchange.getRequest().getMethod().name())) {
                if (!userDto.getRoles().contains("PRODUCER")) {
                    return unauthorized(exchange);
                }
            }
            
            exchange.getAttributes().put("authenticatedUser", userDto);
            
            return chain.filter(exchange);
        })
        .onErrorResume(e -> unauthorized(exchange));
}

    private Mono<Void> unauthorized(ServerWebExchange exchange) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        return exchange.getResponse().setComplete();
    }
}