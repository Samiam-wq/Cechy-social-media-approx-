package org.ac.cst8277.Iftikhar.Usama.repository;

import org.ac.cst8277.Iftikhar.Usama.model.User;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface UserRepository extends ReactiveCrudRepository<User, Long> {
	
    Mono<User> findByUsername(String username);
    Mono<User> findByGithubId(String githubId);
}