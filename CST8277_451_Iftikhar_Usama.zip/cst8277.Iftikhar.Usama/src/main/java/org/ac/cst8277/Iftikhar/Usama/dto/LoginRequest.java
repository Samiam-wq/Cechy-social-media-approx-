package org.ac.cst8277.Iftikhar.Usama.dto;

import lombok.Data;

@Data
public class LoginRequest {
    private String username;
    private String password;
}