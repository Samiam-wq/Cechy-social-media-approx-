package org.ac.cst8277.Iftikhar.Usama.service;

import org.ac.cst8277.Iftikhar.Usama.model.User;
import org.ac.cst8277.Iftikhar.Usama.repository.UserRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final Map<UUID, User> tokenStore = new ConcurrentHashMap<>();

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Mono<UUID> authenticate(String username, String password) {
        return userRepository.findByUsername(username)
            .filter(user -> user.getPassword().equals(password))
            .map(user -> {
                UUID token = UUID.randomUUID();
                tokenStore.put(token, user);
                return token;
            });
    }

    public User validateToken(UUID token) {
        return tokenStore.get(token);
    }
    
    public Mono<User> validateTokenReactive(UUID token) {
        User user = tokenStore.get(token);
        if (user == null) {
            return Mono.empty();
        }
        return Mono.just(user);
    }

    public UUID generateTokenForOAuthUser(User user) {
        UUID token = UUID.randomUUID();
        tokenStore.put(token, user);
        return token;
    }
}