package org.ac.cst8277.Iftikhar.Usama.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;
import java.time.LocalDateTime;

@Data
@Table("posts")
public class Post {
	
    @Id
    private Long id;
    private Long producerId;
    private String content;
    private LocalDateTime createdAt = LocalDateTime.now();
}