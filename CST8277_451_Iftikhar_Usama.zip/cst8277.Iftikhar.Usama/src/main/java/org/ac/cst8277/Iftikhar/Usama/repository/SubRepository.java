package org.ac.cst8277.Iftikhar.Usama.repository;

import org.ac.cst8277.Iftikhar.Usama.model.Subscription;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;

public interface SubRepository extends ReactiveCrudRepository<Subscription, Long> {
	
    Flux<Subscription> findBySubscriberId(Long subscriberId);
}