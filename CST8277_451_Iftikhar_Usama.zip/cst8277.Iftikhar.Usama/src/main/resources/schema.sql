-- The Ledger of Members
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255),
    password VARCHAR(255),
    github_id VARCHAR(255),
    roles VARCHAR(255)
);

-- The Great Hall Board (Notices)
CREATE TABLE IF NOT EXISTS posts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    producer_id BIGINT, -- Links to users.id (The Master)
    content VARCHAR(280),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- The Ledger of Allegiances (Subscriptions)
CREATE TABLE IF NOT EXISTS subscriptions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    subscriber_id BIGINT, -- The Journeyman
    producer_id BIGINT    -- The Master being followed
);